姓名：鄭宇辰
學號：408410035
email:hsa11555@gmail.com   
完成項目：
class Mixed 中的Evaluate Simplify ToFraction函式以及不同參數的constructor
以及< > <= == != + - * / 前後++ 前後-- >> <<的operator
繳交檔案名為：mixed.exe main.cpp Mixed.h Mixed.cpp以及Makefile
可以使用make run來執行
若是遇到繳交執行檔遇到權限不足執行的問題請使用make run來執行

bouns:
額外實做了 Mixed型態 + - * / 整數型態的operator
額外實做了 ＝ 的operator 可以把右邊assign到左邊

reference:main函式的內容參考作業pdf 其中額外新增對於（int,0,0）物件的測試
以及新增x++ ++x x-- --x的測試