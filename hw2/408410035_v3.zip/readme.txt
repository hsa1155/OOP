姓名：鄭宇辰
學號：408410035
email:hsa11555@gmail.com
完成項目：
1.讀取檔案並輸出
2.polydata.txt
3.highestPower函式
4.display函式
5.derivative函式
6.compute函式
7.ans.txt(包含輸入使用的x)

bonus內容：
debug模式 預設不是debug模式 需要修改程式的DEBUG變數來啟動debug模式（第三行）

Reference:
1.解決輸入不是數字的方法
https://www.itread01.com/content/1544509266.html
