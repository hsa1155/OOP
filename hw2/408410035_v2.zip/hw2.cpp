#include<bits/stdc++.h>
#include <fstream>
#define DEBUG 0
using namespace std;
ifstream inp("polydata.txt", ios::in);

int HighestPower(vector<double> poly)
{
    poly[0]=(int)poly[0];
    if(poly[0]+2!=poly.size())
    {
        cout<<endl;
        cout<<"file input error.this input is illegal"<<endl<<endl;;
        cout<<"raw input:";
        for(int j=0; j<poly.size(); j++)
            cout<<poly[j]<<" ";
        cout<<endl<<endl;;
        return -1;
    }
    return poly[0];
}
void display(int HighestPower,vector<double> poly)
{
    int sta=0;// 0 for no output
    for(int i=1; i<=HighestPower+1; i++)
    {
        if(poly[i]==0)
            continue;
        cout<<poly[i];
        sta=1;
        for(int j=0; j<i-1; j++)
            cout<<"*x";
        if(i!=HighestPower+1)
            cout<<" + ";
    }
    if(sta==0)//if no output.putput1
        cout<<0;
    cout<<endl<<endl;;
}
void derivate(int HighestPower,vector<double> poly,vector<double>&depoly)
{
    depoly.push_back(HighestPower-1);
    for(int i=1; i<=HighestPower; i++)
    {
        depoly.push_back(poly[i+1]*i);
    }
}
double compute(int HighestPower,vector<double> poly,double x)
{
    double sum=0;
    for(int i=1; i<=HighestPower+1; i++)
    {
        sum+=poly[i]*pow(x,i-1);
    }

    return sum;
}

int main()
{
    if(DEBUG)
    {
        cout<<"DEBUG MODE"<<endl;

        string buf;
        int counter=0;
        while(getline(cin,buf))
        {
            counter++;
            cout<<"Question "<<counter<<":"<<endl;
            stringstream tmp(buf);
            vector<double> poly;
            vector<double> depoly;
            int geterror=0;
            double a;

            while(!tmp.eof())
            {
                
                if(!(tmp>>a))
                {
                    cout<<endl;
                    cout<<"file input error.this input contains something that is not number"<<endl<<endl;
                    tmp.clear();
                    poly.clear();
                    geterror=1;
                    break;
                }

                poly.push_back(a);
            }
            if(geterror==1)
                continue;
            int HP=HighestPower(poly);
            if(HP<0)
                continue;

            cout<<"f(x)=";
            display(HP,poly);
            derivate(HP,poly,depoly);
            cout<<"f'(x)=";
            display(HP-1,depoly);
            double x;
            cout<<"please input a number x to calculate value"<<endl;
            while(1)
            {
                cin>>x;
                if(cin.fail())
                {
                    cout<<"that is not a number. try again"<<endl;
                    cin.clear();
                    while(cin.get() != '\n')
                    {
                        continue;
                    }
                }
                else
                    break;
            }
            cout<<"f("<<x<<") = "<<compute(HP,poly,x)<<endl<<endl;;
            cout<<"f'("<<x<<") = "<<compute(HP-1,depoly,x)<<endl<<endl;;

        }
    }
    else
    {

        string buf;
        int counter=0;
        while(getline(inp,buf))
        {
            counter++;
            cout<<"Question "<<counter<<":"<<endl;
            stringstream tmp(buf);
            vector<double> poly;
            vector<double> depoly;
            int geterror=0;
            double a;

            while(!tmp.eof())
            {
                
                if(!(tmp>>a))
                {
                    cout<<endl;
                    cout<<"file input error.this input contains something that is not number"<<endl<<endl;
                    tmp.clear();
                    poly.clear();
                    geterror=1;
                    break;
                }

                poly.push_back(a);
            }
            if(geterror==1)
                continue;
            int HP=HighestPower(poly);
            if(HP<0)
                continue;

            cout<<"f(x)=";
            display(HP,poly);
            derivate(HP,poly,depoly);
            cout<<"f'(x)=";
            display(HP-1,depoly);
            double x;
            cout<<"please input a number x to calculate value"<<endl;
            while(1)
            {
                cin>>x;
                if(cin.fail())
                {
                    cout<<"that is not a number. try again"<<endl;
                    cin.clear();
                    while(cin.get() != '\n')
                    {
                        continue;
                    }
                }
                else
                    break;
            }
            cout<<"f("<<x<<") = "<<compute(HP,poly,x)<<endl<<endl;;
            cout<<"f'("<<x<<") = "<<compute(HP-1,depoly,x)<<endl<<endl;;

        }
    }
}
