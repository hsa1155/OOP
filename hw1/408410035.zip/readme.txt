學號：408410035 
姓名：鄭宇辰
email:hsa11555@gmail.com
完成項目：
c++ java python makefile 以及輸出檔案
可以正確計算並輸出在cmd以及檔案中

bonus內容：
c++ java python的程式碼中皆包含將結果輸出到檔案的部份
c++輸出至cpp_result.txt
java輸出至java_result.txt
python輸出至py_result.txt
雖然程式設計成可以設計成可以多次輸入
但要重複執行的話建議先刪掉上次產生的txt檔 否則文檔內容會跟上次混在一起
makefile中有 cleantxt 可以刪除產生的檔案

reference:
python輸出檔案程式碼的相關參考
https://medium.com/ccclub/ccclub-python-for-beginners-tutorial-bf0648108581

java輸出檔案程式碼的參考
https://lolikitty.pixnet.net/blog/post/24905073

但程式碼都是自己撰寫 沒有複製

