姓名：鄭宇辰
學號：408410035
email:hsa11555@gmail.com
完成項目：完成class Point,Line,ConvexHull 以及其中所有要求的函式（但是沒有全部都輸出訊息）
並且有為程式計時 其中 由於輸出內容可能很長 因此將convexhull演算法中 印出結果的部份都住解了 只留下輸出output1幾個點以及output2幾個點 以及所耗時間
另外 由於brute force算法中 使用javis 算法做點的排序 因此在輸出訊息時 burteforce的訊息內會包含關於javis的訊息 這是正常現象
輸入的檔案名稱為 input.txt
burteforce輸出到Output_brutal.txt
javis輸出到Output_Javis.txt
輸入少於三個點時 不會產生任何output 

bonus：有make run 使用後可以直接執行 以及make clean功能

reference:
計時參考：
https://nosleep.pixnet.net/blog/post/205120138-%E7%A8%8B%E5%BC%8F%E9%96%8B%E7%99%BC-%7C-%5Blinux%5D%5Bc%5D-%E4%BD%BF%E7%94%A8-gettimeofday%28%29-%E5%87%BD%E5%BC%8F%E8%A8%88%E7%AE%97

外積參考（isOnRight使用的判斷方法）
http://web.ntnu.edu.tw/~algo/ConvexHull.html

角度計算參考：
https://blog.csdn.net/xiangxianghehe/article/details/99544534
