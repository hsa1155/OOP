姓名：鄭宇辰
學號：408410035
email:hsa11555@gmail.com   
完成項目:
main.cpp LinkedList.cpp Polygon.cpp 皆完成並正常運作
polydata.txt 內含自己使用的測資 使用了四筆測資 皆有附在檔案中 助教批改時若有需要可以覆蓋polydata.txt的內容
其中程式所有要求的函式皆有實做
有一部分的內容稍做修改
在linkedlist中
額外增加了一個size變數 用以儲存現在的linkedlist大小 讓其餘部份的運作可以更流暢簡潔
還有point的結構中 新增一個way變數 以迎合輸入時的方向問題
其中其他所有函式執行時皆會輸出訊息 除了clear函數的輸出是多次執行deleteCurrentNode函是的結果
以及isEmpty函式因為多次使用會使輸出變得很雜亂 因此將輸出內容註解掉了
另外有做出printall函式 用以debug用 作業中沒有使用到

在Polygon中
所有函式都有實做並可以正常運作
唯一特別的點是isCollide函式在輸入為一條線而不是多邊型時還是會運作
但是會額外輸出警告輸入是線不是多邊形

在main中則是按照課程網頁上助教要求的內容寫

bonus內容：多筆測資

reference:無

