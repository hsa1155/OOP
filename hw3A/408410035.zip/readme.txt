姓名：鄭宇辰
學號：408410035
email:hsa11555@gmail.com   
完成項目：
part1：class node ,class stack 以及main函式以及兩個class中所有函式
其中 pop時若是stack為空的會回傳0x3f3f3f3f 因為stack中可能會有-1存在 所以改用這個不常用的數字（不過程式中實際上沒有用到回傳值）
node的constructor有三種版本 讓程式可以更簡潔
雖然有交上輸入內容 但必須要手動鍵盤輸入 或是複製貼上也可以
繳交的檔案名稱：node.cpp mystack.cpp main_stack.cpp stack_inp.txt
編譯後檔案名稱：stack.exe

part2:class Tnode,class Btree 以及main函式以及兩個class中要求的所有函式
其中 Tnode中多了兩個函式print 以及 destroy用以印出樹的長相還有刪除所有節點
繳交的檔案名稱：Tnode.cpp main_tree.cpp Btree.cpp treenode.txt 
編譯後檔案名稱：tree.exe

makefile
可以一次編譯全部東西

bonus內容：
兩個part皆會輸出到外部txt檔案
檔案名稱：stack_ans.txt tree_ans.txt

reference:
part2中建樹的方法參考
https://www.codespeedy.com/build-binary-tree-in-cpp-competitive-programming/
稍做修改以迎合輸入規範


